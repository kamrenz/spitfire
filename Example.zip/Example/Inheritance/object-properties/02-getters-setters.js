/**
 * Basic object.
 **/
var rectangle = {
	width: 10, 
	height: 20,
	area: function() {
		return this.width * this.height;
	}
};
console.log(rectangle);
console.log('Area: ' + rectangle.area());

/**
 * Creating a property with getters.
 **/
var rectangleA = {
 	width: 10,
 	height: 20,
 	//Don't need to set this property up
 	//  Useful to know what properties you plan on defining
 	area: null,
 	isLargeBox: false
};

Object.defineProperty(rectangleA, 'area', {
 	get: function() {
 		return this.width * this.height;
 	},
 	set: function() {
 		console.log('You cannot set the area directly');
 		//throw new Error('You cannot set the area directly');
 	}
});

/**
 * Creating a property with setters.
 **/
var rectangleD = {
  width: 10,
  height: 20
};

//Notice the oddity about the _isLargeBox or this._isLargeBox
// Typically this kind of work would be done in a factory
// function or a constructor in which the _isLargeBox would
// be scoped to the function
Object.defineProperty(rectangleD, 'isLargeBox', {
  get: function() {
    console.log('Getter isLargeBox');
    //return _isLargeBox
    return this._isLargeBox
  },
  set: function(value) {
    console.log('Setter isLargeBox');
    //_isLargeBox = value;
    this._isLargeBox = value;
  }
});

rectangleD.isLargeBox = true;
console.log('isLargeBox: ' + rectangleD.isLargeBox);

/**
 * Creating multiple object properties.
 **/
var rectangleC = {};
 
Object.defineProperties(rectangleC, {
 	'area': {
 		get: function() {
 			return this.width * this.height;
 		},
 		set: function() {
 			console.log('You cannot set the area directly');
 			//throw new Error('You cannot set the area directly');
 		}
 	}, 
 	'width': {
    value: 10,
    writeable: false
  }, 
  'height': {
    value: 20,
    writeable: false
  },
  'isLargeBox': {
    value: false,
    writeable: true
  }
 });

 //Access the area
 console.log('The area is: ' + rectangleA.area);
 //Change the area
 console.log('Try to change the area');
 rectangleA.area = 200;

 /**
 * Creating a property with getters and setters.
 * - Not going to use set very much... it allows for other 
 *    statements to be run when the property is assigned a value
 * - Below shows an example of what not to do :)
 * 		Don't use get/set on simple properties... instead use value
 **/
 var rectangleB = {
 	width: 10,
 	height: null,
 	//Don't need to set this property up
 	//  Useful to know what properties you plan on defining
 	area: null
 };

 Object.defineProperty(rectangleB, 'area', {
 	enumerable: true,
 	configurable: true,
 	get: function() {
 		return this.width * this.height;
 	},
 	set: function() {
 		console.log('You cannot set the area directly');
 		//throw new Error('You cannot set the area directly');
 	}
 });

//Set is really for setting up calculated properties
 Object.defineProperty(rectangleB, 'height', {
 	get: function() {
 		//Shouldn't do this.height becuase it will call itself over and over
 		return this.newHeight;
 	},
 	set: function(value) {
 		//Shouldn't do this.height becuase it will call itself over and over
 		this.newHeight = value;
 	}
 });

 //Set the height
 console.log('??: ' + rectangleB.height);
 rectangleB.height = 20;
 //Change the area
 console.log('Try to change the area');
 console.log(rectangleB.area);


//More weeds...

var o = {}; // Creates a new object

var bValue = 38;
Object.defineProperty(o, 'b', {
  get: function() { return bValue; },
  set: function(newValue) { bValue = newValue; },
  enumerable: true,
  configurable: true
});
console.log(bValue);
console.log(o.b); // 38