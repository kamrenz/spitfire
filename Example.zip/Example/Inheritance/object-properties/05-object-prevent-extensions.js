// If you use strict TypeErrors will be thrown rather than the code failing silently
// 'use strict';

console.log('Prevent object extensions');
var obj = { foo: 1, bar: 2};
console.log(obj);
console.log(Object.getOwnPropertyDescriptor(obj, 'bar')); 

Object.preventExtensions(obj);
console.log('Can the object be extended: ' +Object.isExtensible(obj));
console.log(Object.getOwnPropertyDescriptor(obj, 'bar')); 


console.log('Non-extensible objects can have property values changed');
// Changing property values on a sealed object still works.
obj.foo = 'quux';
console.log('Changed the foo object property value: ' + obj.foo);
console.log(obj);

console.log('Extensible objects cannot add properties');
// If use strict is on this will throw: 
//	TypeError: Can't add property baz, object is not extensible
obj.baz = 4;    // doesn't add the property
console.log('Trying to add property baz: ');
console.log(obj);

console.log('Extensible objects can delete properties');
delete obj.foo; // does delete the property
console.log('Trying to delete property foo: ');
console.log(obj);


console.log('Explore descriptors');
//Non-extensible objects can't have object descriptors changed
//Non-extensible object property values can change
obj.bar = 8;
console.log(obj.bar);
//Check descriptor
console.log(Object.getOwnPropertyDescriptor(obj, 'bar')); 

//	You can't change writability
Object.defineProperty(obj, 'bar', { 
  writeable: false 
}); 
//Check descriptor again after changing it
//	Descriptor won't be changed
console.log(Object.getOwnPropertyDescriptor(obj, 'bar')); 
//No longer can modify property values
obj.bar = 10;
console.log(obj.bar);

//	You can't change enumerability
Object.defineProperty(obj, 'bar', { 
  enumerability: false 
}); 
//Check the descriptor
//	Descriptor won't be changed
console.log(Object.getOwnPropertyDescriptor(obj, 'bar')); 

//	You can't change configurability
Object.defineProperty(obj, 'bar', { 
  configurable: true 
}); 
//Check the descriptor
//	Descriptor won't be changed
console.log(Object.getOwnPropertyDescriptor(obj, 'bar')); 

// Can convert data properties to accessors and vice versa.
//	Descriptor won't be changed
//	TypeError: Cannot define property:foo, object is not extensible.
Object.defineProperty(obj, 'foo', { 
  get: function() { 
  	return 'g'; 
  } 
}); 
console.log(Object.getOwnPropertyDescriptor(obj, 'foo')); 