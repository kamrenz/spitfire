//Prototype object for the object being created
var proto = {
  shared: true,
  hatColor: 'blue'
};

//Creating an object with a prototype and its own 
//  instance properties/methods
var obj = Object.create(proto, {
  init: {
    value: function(foo) {
      console.log('initialize');
      this.foo = foo;
    }
  },
  // foo is a data property
  foo: { writable: true, configurable: true, value: 0 },
  // bar is an accessor property
  bar: {
    configurable: false,
    get: function() { return 10; },
    set: function(value) { console.log('Nope'); }
  },
  // properties can have any value, including functions
  baz: {
    value: function(x) { console.log('baz says', x); }
  }
});

//See the object
console.log(obj);
//Initialize the object
obj.init(42)
console.log(obj);


var obj = Object.create(Object.prototype, {
  init: {
    value: function(foo) { this.foo = foo; }
  },
  // foo is a data property
  foo: { 
    writable: true, 
    configurable: true, 
    value: 0 
  },
  // properties can have any value, including functions
  baz: {
    value: function(x) { console.log('baz says', x); }
  }
});

obj.init(42);