//Prototype object for the object being created
var proto = {
  shared: true,
  hatColor: 'blue'
};

//Creating an object with a prototype and its own 
//  instance properties/methods
var obj = Object.create(proto, {
  init: {
    value: function(foo) {
      console.log('initialize');
      this.foo = foo;
    }
  },
  // foo is a data property
  foo: { writable: true, enumerable: true, configurable: true, value: 0 },
  // bar is an accessor property
  bar: {
    configurable: false,
    enumerable: true,
    get: function() { return 10; },
    set: function(value) { console.log('Nope'); }
  },
  // properties can have any value, including functions
  baz: {
    value: function(x) { console.log('baz says', x); }
  }
});

//See the object
console.log(obj);
//Initialize the object
obj.init(42)
console.log(obj);

//Object Keys: Doesn't show you anything that is not marked enumerable
console.log('Object Keys'); 
console.log(Object.keys(obj));  // ['foo', 'bar']
//Object Property Names: Shows all properties... enumerable or not
console.log(Object.getOwnPropertyNames(obj));  // ['init', foo', 'bar', 'baz']
//Object Property Descriptor: 
console.log(Object.getOwnPropertyDescriptor(obj, 'foo')); // Object {value: 42, writable: true, enumerable: true, configurable: true}
//Object Has Own Property Check
console.log(obj.hasOwnProperty('foo'));  // true