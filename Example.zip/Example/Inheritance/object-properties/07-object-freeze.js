// If you use strict TypeErrors will be thrown rather than the code failing silently
//'use strict';

console.log('Freezing an object');
var obj = { foo: 1, bar: 2};
console.log(obj);

Object.freeze(obj);
Object.isFrozen(obj); // true
console.log('Is the object frozen: ' +Object.isFrozen(obj));
console.log(Object.getOwnPropertyDescriptor(obj, 'foo')); 

console.log('Frozen objects cannot have property changed');
obj.foo = 'quux'; // doesn't change the value
console.log('Trying to change property value');
console.log(obj);
console.log('Trying to add a property');
obj.baz = 4;      // doesn't add the property
console.log(obj);
console.log('Trying to delete a property');
delete obj.foo;   // doesn't delete the property
console.log(obj);


//Freeze doesn't freeze nested object references
// Have students do this during lab time
console.log('Freeze not applied to nested objects');
var hat = { 
	color:'blue'
};
var person = {
	//Nested object reference
	accessory: hat,
	name: 'Kamren'
};

Object.freeze(person);
//Can't change the name property
console.log('Changing top property will not work');
person.name = 'Bill';
console.log(person.name);  //Still Kamren
//Can change the accessory color
console.log('Changing nested property will work');
person.accessory.color = 'orange';
console.log(person.accessory.color);
//Make nested also frozen
Object.keys(person).forEach( function(key, value) {
  	if ( typeof person[key] === 'object' ) {
    	//constantize( obj[key] );
    	Object.freeze(person[key]);
  	}
});

console.log('After deep freeze changing nested property will not work');
person.accessory.color = 'green';
console.log(person.accessory.color);





