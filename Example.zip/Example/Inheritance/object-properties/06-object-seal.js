// If you use strict TypeErrors will be thrown rather than the code failing silently
//'use strict';

console.log('Sealing an object');
var obj = { foo: 1, bar: 2};
console.log(obj);

Object.seal(obj);
console.log('Is the object sealed: ' +Object.isSealed(obj));


console.log('Sealed objects can have property values changed');
// Changing property values on a sealed object still works.
obj.foo = 'quux';
console.log('Changed the foo object property value: ' + obj.foo);
console.log(obj);

console.log('Sealed objects cannot add properties');
// If 'use strict' it will throw an error:
//	TypeError: Can't add property baz, object is not extensible
obj.baz = 4;    // doesn't add the property
console.log('Trying to add property baz: ');
console.log(obj);

console.log('Sealed objects cannot delete properties');
// If 'use strict' it will throw an error:
//	TypeError: Cannot delete property 'foo' of #<Object>
delete obj.foo; // doesn't delete the property
console.log('Trying to delete property foo: ');
console.log(obj);


console.log('Explore descriptors');
//Changing Sealed object descriptors doesn't work
//Sealed object property values can change
obj.bar = 8;
console.log(obj.bar);
//Check descriptor
console.log(Object.getOwnPropertyDescriptor(obj, 'foo')); 

//	You can't change writability
Object.defineProperty(obj, 'bar', { 
  writeable: false 
}); 
//Check descriptor again after changing it
//	Descriptor won't be changed... fails silently
console.log(Object.getOwnPropertyDescriptor(obj, 'foo')); 
//Can still modify property values
obj.bar = 10;
console.log(obj.bar);

//	You can't change enumerability
Object.defineProperty(obj, 'bar', { 
  enumerability: false 
}); 
//Check the descriptor
//	Descriptor won't be changed... fails silently
console.log(Object.getOwnPropertyDescriptor(obj, 'foo')); 

//	You can't change configurability
//	  Will throw a TypeError: Cannot redefine property: bar
Object.defineProperty(obj, 'bar', { 
  configurable: true 
}); // throws a TypeError
//Check the descriptor
console.log(Object.getOwnPropertyDescriptor(obj, 'foo')); 

// Can't convert data properties to accessors, or vice versa.
//	  Will throw a TypeError: Cannot redefine property: foo
Object.defineProperty(obj, 'foo', { 
  get: function() { 
  	return 'g'; 
  } 
}); // throws a TypeError