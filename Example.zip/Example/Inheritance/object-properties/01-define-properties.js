/**
 * Normal object.
 **/
var obj = { x:42 };
console.log('Normal object');
console.log(obj);

/**
 * Defining property that is writable, enumerable and configurable.
 **/
var obja = {};
Object.defineProperty(obja, 'x', {
  value: 42,
  writable: true,
  enumerable: true,
  configurable: true
});
console.log('Defined Object properties');
console.log(obja);
//Try to change the value
console.log('The property value can be changed');
obja.x = 30;
//Notice the value of property x did change
console.log(obja);
console.log('The property is enumerable');
console.log('for-in loop');
for (var i in obja) {
	console.log(i);
}
console.log('Object.keys');
console.log(Object.keys(obja));
console.log('Check enumerability:' + obja.propertyIsEnumerable('x'));
//Try to configure the property
console.log('The property is configurable: configurable');
Object.defineProperty(obja, 'x', {
	enumerable: false
});
console.log('Check enumerability:' + obja.propertyIsEnumerable('x'));
console.log('Check if it still hasOwnProperty("x"):' + obja.hasOwnProperty('x'));
//Try to delete the property
console.log('The property is configurable: deletable');
delete obja.x;
console.log(obja);

/**
 * Defining property this is not writeable.
 **/
var objb = {};
Object.defineProperty(objb, 'x', {
  value: 42,
  writable: false,
  enumerable: true,
  configurable: true
});
console.log('Defined Object properties: not writeable');
console.log(objb);

//Try to change the value
console.log('Try to change the value of x to 30');
objb.x = 30;
//Notice the value of property x didn't actually change
console.log(objb);

/**
 * Defining a property that is not enumerable.
 **/
var objc = {};
Object.defineProperty(objc, 'x', {
  	value: 42,
  	writable: true,
  	enumerable: false,
  	configurable: true
});
Object.defineProperty(objc, 'y', {
	value: 33,
	writeable: true,
	enumerable: true,
	configurable: true
});
console.log('Defined Object properties: not enumerable');
console.log(objc);
console.log('for-in loop: should only print property y ... no x');
for (var i in objc) {
	console.log(i);
}
console.log('Object.keys: should be an array with y ... no x');
console.log(Object.keys(objc));
console.log('Check enumerability:' + objc.propertyIsEnumerable('x'));

/**
 * Defining a property that is not configurable.
 **/
var objd = {};
Object.defineProperty(objd, 'x', {
	value: 42,
	writable: true,
	enumerable: true,
	configurable: false
});
console.log('Defined Object properties: not configurable');
console.log(objd);
//Try to delete the property
console.log('The property is not configurable: deletable');
console.log('Try to delete');
//No exception will be thrown, but the property will not be deleted
delete objd.x;
console.log(objd);
//Try to configure the property
console.log('Check enumerability:' + objd.propertyIsEnumerable('x'));
console.log('The property is not configurable: configurable');
console.log('Try to configure');
//An exception will be thrown when trying to delete the property
Object.defineProperty(objd, 'x', {
	enumerable: false
});
console.log('Check enumerability:' + objd.propertyIsEnumerable('x'));
console.log('Check if it still hasOwnProperty("x"):' + objd.hasOwnProperty('x'));


