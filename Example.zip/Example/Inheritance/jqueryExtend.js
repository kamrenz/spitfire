'use strict';

//Prototype to be used for city instances
var proto = {
  hasMayor: true,
  toString: function() {
    return this.name + ' has ' + this.population + ' people';
  }
};

//Factory Function to create instances
var makeCity = function(params) {
  //Creating object via proto 
  //  Shared between all instances
  var city = {};
  city = $.extend(city, proto, params);

  //Return the object instance
  return city;
};

var lansing = makeCity({name: 'Lansing', population: 110000});
var boulder = makeCity({name: 'Boulder', population: 103000});

console.log('Name: ' + lansing.name);
console.log('Population: ' + lansing.population);
console.log('Do you have a mayor: ' + lansing.hasMayor);
console.log(lansing.toString());
console.log(lansing instanceof Object);
console.log(lansing.constructor === Object);

console.log('Name: ' + boulder.name);
console.log('Population: ' + boulder.population);
console.log('Do you have a mayor: ' + boulder.hasMayor);
console.log(boulder.toString());
console.log(boulder instanceof Object);
console.log(boulder.constructor === Object);
