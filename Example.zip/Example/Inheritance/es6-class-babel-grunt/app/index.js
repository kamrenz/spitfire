'use strict';

class UrbanCenter {
	constructor(numOfPeople) {
  	this.numOfPeople = numOfPeople;
  }

  getNumOfPeople() {
    return this.numOfPeople;
  }

  toString() {
  	return 'Urban Center with ' + this.numOfPeople + ' people';
  }

  //Class/Utility/Static method 
  //  This method exists only on the City object not on the instances
  static moreHouseHolds(cityA, cityB) {
    if (cityA.numOfPeople > cityB.numOfPeople) {
      return cityA;
    } else {
      return cityB;
    }
  }

}

class City extends UrbanCenter {
	constructor(numOfPeople, hasMayor){
		super(numOfPeople);
		this.hasMayor = hasMayor;
	}

	toString() {
  	var superText = super.toString();
  	return superText.replace('Urban Center', 'City');
	}
}

var city = new City(100000, true);
console.log('Population: ' + city.getNumOfPeople());
//It is a public property after all
console.log('Population: ' + city.numOfPeople);
console.log(city.toString());
console.log(city instanceof City);
console.log(city instanceof UrbanCenter);
console.log(city instanceof Object);
console.log(city.constructor === City);
console.log('Do you have a mayor: ' + city.hasMayor);

var urbanCenter = new UrbanCenter(111000);
console.log('Population: ' + urbanCenter.getNumOfPeople());
console.log(urbanCenter.toString());
console.log(urbanCenter instanceof UrbanCenter);
console.log(urbanCenter instanceof Object);
console.log(urbanCenter.constructor === UrbanCenter);
console.log('Do you have a mayor: ' + urbanCenter.hasMayor);

var cityB = new City(50000, true);

var largerCity = City.moreHouseHolds(city, cityB);
console.log('The larger population is ' + largerCity.getNumOfPeople());