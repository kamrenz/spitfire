'use strict';

module.exports = function(grunt) {

  // Load grunt tasks automatically
  require('load-grunt-tasks')(grunt);

  // Time how long tasks take. Can help when optimizing build times
  require('time-grunt')(grunt);

  // Project configuration.
  grunt.initConfig({

    'babel': {
      options: {
        sourceMap: true
      },
      dist: {
        files: {
          'dist/index.js': 'app/index.js'
        }
      }
    }

  });

  grunt.registerTask('default', ['babel']);

};