'use strict';

function UrbanCenter(numOfPeople) {
  this.numOfPeople = numOfPeople;
}

UrbanCenter.prototype = {
  constructor: UrbanCenter,
  getNumOfPeople: function() {
    return this.numOfPeople;
  },
  toString: function() {
    return 'Urban Center with ' + this.numOfPeople + ' people';
  }
};

function City(numOfPeople, hasMayor) {
  UrbanCenter.call(this, numOfPeople);
  this.hasMayor = hasMayor;
}

City.prototype = new UrbanCenter();
City.prototype.constructor = City;
City.prototype.toString = function() {
  //return "City with " + this.numOfPeople + " people";
  var superText = UrbanCenter.prototype.toString.call(this);
  return superText.replace('Urban Center', 'City');
};


var city = new City(100000, true);
console.log('Population: ' + city.getNumOfPeople());
console.log(city.toString());
console.log(city instanceof City);
console.log(city instanceof UrbanCenter);
console.log(city instanceof Object);
console.log(city.constructor === City);
console.log('Do you have a mayor: ' + city.hasMayor);

var urbanCenter = new UrbanCenter(111000);
console.log('Population: ' + urbanCenter.getNumOfPeople());
console.log(urbanCenter.toString());
console.log(urbanCenter instanceof UrbanCenter);
console.log(urbanCenter instanceof Object);
console.log(urbanCenter.constructor === UrbanCenter);
console.log('Do you have a mayor: ' + urbanCenter.hasMayor);
