'use strict';

//Variables
var anchor = document.getElementsByTagName('a')[0];
var inputList = document.getElementsByTagName('input');
var textInput = inputList[0];
var checkboxInput = inputList[1];

//Accessing the attributes
console.log(anchor.attributes);
console.log(anchor.getAttribute('target'));
//Accessing the properties
console.log(anchor.target);
console.log(anchor.nodeName);

//Accessing the properties vs attributes on inputs
console.log(checkboxInput.getAttribute('checked'));
console.log(checkboxInput.checked);


var $anchor = $('a');
var $inputList = $('input');
var $textInput = $inputList.first();
var $checkboxInput = $('input[type="checkbox"]');

//Accessing the attributes
console.log($anchor.attr('target'));
//Accessing the properties
console.log($anchor.prop('target'));
console.log($anchor.prop('nodeName'));

//Accessing the properties vs attributes on inputs
console.log($checkboxInput.attr('checked'));
console.log($checkboxInput.prop('checked'));