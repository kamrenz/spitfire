/**
 *	Example of the Module Revealing Pattern.
 *  Main JavaScript file
 **/
(function () {
	'use strict';

	//DI namespace
	window.DI = window.DI || {};

	//Validation button handle
	var VALIDATION_BUTTON_HANDLE = $('#validateKey');
	//Validation status handle
	var VALIDATION_STATUS_HANDLE = $('#validationStatus');

	//Validating if the product key has been saved
	function validateSaved() {
		//Getting the save status
		var status = DI.ProductKey.getSaveStatus();
		//Visually displaying the save status
		VALIDATION_STATUS_HANDLE.text(status);

		//Toggling the save status
		if (DI.ProductKey.isSaved()) {
			//Toggle the saved state from true to false
			DI.ProductKey.setSaved(false);
		} else {
			//Toggle the saved state from false to true
			DI.ProductKey.setSaved(true);
		}

	}

	//Main
	$(function() {
		//Setting up event listener for the validation button handle clicking
		VALIDATION_BUTTON_HANDLE.on('click', validateSaved);
	});

})();

