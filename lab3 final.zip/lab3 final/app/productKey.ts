/**
 *	Product Key module
 *	ES6 Module
 **/
'use strict';

const PRODUCT_ID: string = '4328TTY';
const SAVED_STATUS: string = PRODUCT_ID + ' has been saved';
const NON_SAVED_STATUS: string = PRODUCT_ID + ' has not been saved';
let hasBeenSaved: boolean = false;
let saveStatus: string = NON_SAVED_STATUS;

//Get the save status of the product key
export function getSaveStatus(): string {
	return saveStatus;
}

//Has the product key been saved
export function isSaved(): boolean {
	return hasBeenSaved;
}

//Set the save status of the product key
export function setSaved(status: boolean) {
	//Truthify any value being passed in
	hasBeenSaved = !!status;

	//Set the status message based on truthy check
	if (hasBeenSaved) {
		saveStatus = SAVED_STATUS;
	} else {
		saveStatus = NON_SAVED_STATUS;
	}
}