/// <reference path="../typings/globals/jquery/index.d.ts" />

/**
 *	Example of ES6 modules
 *	Main JavaScript Module
 **/
'use strict';

//Product Key Module
import * as productKey from './productKey';
import jQuery from 'jquery';
//Typing issue with jQuery: https://github.com/DefinitelyTyped/DefinitelyTyped/issues/6315

//Validation button handle
const VALIDATION_BUTTON_HANDLE = jQuery('#validateKey');
//Validation status handle
const VALIDATION_STATUS_HANDLE = jQuery('#validationStatus');

//Validating if the product key has been saved
let validateSaved  = () => {
	//Getting the save status
	let status: string = productKey.getSaveStatus();
	//Visually displaying the save status
	VALIDATION_STATUS_HANDLE.text(status);

	//Toggling the save status
	if (productKey.isSaved()) {
		//Toggle the saved state from true to false
		productKey.setSaved(false);
	} else {
		//Toggle the saved state from false to true
		productKey.setSaved(true);
	}
	
}

//Main
jQuery(() => {
	//Setting up event listener for the validation button handle clicking
	VALIDATION_BUTTON_HANDLE.on('click', validateSaved);
});


