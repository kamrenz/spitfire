import { Component, OnInit } from '@angular/core';
import { Report } from './report';


@Component({
  selector: 'app-card',
  templateUrl: './card.component.html',
  styleUrls: ['./card.component.css']
})
export class CardComponent implements OnInit {

  report: Report;
  index: number;
  image: string;

  constructor() {
      this.randomizeImage();
  }

  randomizeImage(): void {
      const images: string[] = [
          'fa-angellist',
          'fa-smile-o',
          'fa-thumbs-o-up'
      ];
      const random = Math.round(Math.random()*2);

      this.image = images[random];
  }

  isOdd(): boolean {
      return Boolean(this.index % 2);
  }

  ngOnInit() {
  }

}
